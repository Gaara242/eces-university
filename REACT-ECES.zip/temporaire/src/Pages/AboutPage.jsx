import React, { useEffect, useRef } from 'react';
import { SlidIn } from '../assets/animations/heroAnimations';
import { HeroSection1 } from '../Components/HeroSection';
import { Link } from 'react-router-dom';

const AboutPage = () => {
    const containerRef = useRef(null);

    useEffect(() => {
        const ctx = SlidIn(containerRef);
        return () => ctx.revert();
    }, []);

    return (
      <>

      <HeroSection1 title={"À Propos de Nous"} description={"L'ECES s'engage à former la prochaine génération de professionnels qualifiés"}></HeroSection1>
      <div ref={containerRef} className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
          {/* En-tête */}

          {/* Section Mission */}
      <div className="mb-20 animate-slide">
          <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-3xl font-semibold text-gray-800 mb-6">Notre Mission</h2>
              <p>
              L'ECES s'engage à former la prochaine génération de professionnels qualifiés 
                en offrant une éducation de qualité, accessible et adaptée aux besoins du marché. 
                Notre approche pédagogique innovante combine théorie et pratique, permettant 
                à nos étudiants de développer les compétences essentielles pour réussir dans 
                leur carrière professionnelle.
              </p>
          </div>
      </div>
      <div className="mb-20 animate-slide">
          <h2 className="text-3xl font-semibold text-gray-800 mb-12 text-center">Notre Équipe</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                  { name: "John Doe", role: "Directeur Technique" },
                  { name: "Jane Smith", role: "Designer UX" },
                  { name: "Marc Johnson", role: "Développeur Full-Stack" }
              ].map((member, index) => (
                  <div key={index} className="bg-white rounded-xl shadow-lg p-6 transform hover:-translate-y-2 transition-all duration-300">
                      <div className="w-20 h-20 bg-blue-100 rounded-full mx-auto mb-4"></div>
                      <h3 className="text-xl font-semibold text-gray-800 text-center">{member.name}</h3>
                      <p className="text-gray-500 text-center">{member.role}</p>
                  </div>
              ))}
          </div>
      </div>

          <div className="mb-20 animate-slide">
              <h2 className="text-3xl font-semibold text-gray-800 mb-12 text-center">Nos Valeurs</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[
                      { title: "Innovation", desc: "Toujours à la recherche de nouvelles solutions" },
                      { title: "Qualité", desc: "Excellence dans chaque ligne de code" },
                      { title: "Collaboration", desc: "Travailler ensemble pour de meilleurs résultats" }
                  ].map((value, index) => (
                      <div key={index} className="bg-blue-50 rounded-xl p-6 hover:bg-blue-100 transition-colors duration-300">
                          <h3 className="text-xl font-semibold text-blue-600 mb-3">{value.title}</h3>
                          <p className="text-gray-600">{value.desc}</p>
                      </div>
                  ))}
              </div>
          </div>

          <div className="text-center animate-slide">
              <h2 className="text-3xl font-semibold text-gray-800 mb-6">Contactez-Nous</h2>
              <p className="text-gray-600 mb-8">
                  Vous avez un projet en tête ? N'hésitez pas à nous contacter pour en discuter.
              </p>
              <Link to={'/contact'} className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-300 shadow-lg">
                  Prendre Rendez-vous
              </Link>
          </div>
      </div>
  </div>
    
          </>
        
    );
};

export default AboutPage;