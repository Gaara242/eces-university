import React, { useEffect, useRef, useState } from 'react';
import { GiOpenBook, GiChemicalDrop, GiThink, GiComputing} from 'react-icons/gi';
import { HeroSection } from "../Components/HeroSection";
import { Cours } from '../Components/cours';
import { HorizontalCard } from '../Components/card';
import { BiJoystickButton } from 'react-icons/bi';
import {  MdGroups } from 'react-icons/md';
import { PiBankBold } from 'react-icons/pi';
import { FaHandHoldingMedical } from 'react-icons/fa';
import { FaComputer } from 'react-icons/fa6';
import { SlidIn } from '../assets/animations/heroAnimations';


export default function HomePage () {
    const containerRef = useRef(null);

    useEffect(() => {
        const ctx = SlidIn(containerRef);
        return () => ctx.revert();
    }, []);

    return (
        <>
            <section ref={containerRef} className="min-h-screen font-sans scroll-smooth" >
                <HeroSection/>
                <section  className="py-20 bg-white">
                    <div className="container mx-auto px-6 animate-slide">
                        <div className="max-w-4xl mx-auto text-center space-y-6">
                        <GiThink className="text-6xl text-blue-800 mx-auto animate-pulse" />
                        <h2 className="text-3xl font-bold text-blue-800">Bienvenue</h2>
                        <p className="text-gray-600 leading-relaxed">
                            L'École Communautaire de l'Enseignement Supérieur est une institution d'enseignement supérieur qui se distingue par son engagement envers l'éducation de qualité et l'inclusion communautaire. Fondée sur des valeurs de diversité, d'égalité des chances et d'excellence académique, cette école vise à offrir des opportunités d'apprentissage enrichissantes à ses étudiants.
                        </p>
                        </div>
                    </div>
                    <div className="flex flex-col items-center pt-20 gap-6 bg-zinc-150 animate-slide">
                        <img className='h-40 w-40 rounded-full ' src="/images/Ado_chinoise.jpg" alt="" />
                        <p className=' text-3xl italic text-amber-800'>Directrice</p>
                        <img src="/images/signature.png" alt="" />
                    </div>
                </section>
                <section  className=" py-20 bg-gray-200 animate-slide">
                    <div className="container mx-auto px-6">
                    <h2 className="text-4xl font-bold text-blue-800 text-center mb-12">Enseignent</h2>
                    <div className="grid md:grid-cols-2 gap-8">
                        {[  {name: 'John Doe', image:'/images/Ado_chinoise.jpg', competence:'"Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium aspe "'},
                            {name: 'John Doe', image:'/images/Ado_chinoise.jpg', competence:'"Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium aspe"'}
                        ].map((item) => (
                            <HorizontalCard props={item}/>
                        ))}
                    </div>
                    </div>
                </section>
                <section className="py-20 bg-gray-200">
                    <div className="container mx-auto px-6 ">
                        <h2 className="text-3xl font-bold text-center text-blue-800 mb-4 font2">LES PLUS POPULAIRE</h2>
                        <hr className='w-60 h-1 bg-blue-800 m-auto' />
                        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mt-16">
                        {[{ icon: <FaComputer className="text-4xl" />, title: 'Genie Informatique' },
                            { icon: <GiOpenBook className="text-4xl" />, title: 'Comptabilité' },
                            { icon: <MdGroups className="text-4xl" />, title: 'Ressource Humaines' },
                            { icon: <FaHandHoldingMedical className="text-4xl" />, title: 'Asistant Medical' },
                            { icon: <GiComputing className="text-4xl" />, title: 'Data Science' },
                            { icon: <PiBankBold className="text-4xl" />, title: 'Banque et Finance' },
                            { icon: <BiJoystickButton className="text-4xl" />, title: 'Mechatronique' },
                            { icon: <GiChemicalDrop className="text-4xl" />, title: 'Sciences de la Terre' }].map((course) => (
                            <Cours course={course}></Cours>
                        ))}
                        </div>
                    </div>
                </section>
            </section>
        </>
    )
}

