import { useState, useEffect } from 'react';
import VisiteComponent from "../Components/VisiteComponent";
import { HeroSection, HeroSection1 } from '../Components/HeroSection';
import { BiArrowFromTop, BiSolidArrowFromBottom } from 'react-icons/bi';

function FilierePage(){
    const [filter, setFilter] = useState('all');
    const [showScroll, setShowScroll] = useState(false);

    useEffect(() => {
        const checkScrollTop = () => {
            if (!showScroll && window.pageYOffset > 400){
                setShowScroll(true);
            } else if (showScroll && window.pageYOffset <= 400){
                setShowScroll(false);
            }
        };
        window.addEventListener('scroll', checkScrollTop);
        return () => window.removeEventListener('scroll', checkScrollTop);
    }, [showScroll]);

    const filieres = [
        {
            title: 'Genie informatique',
            image: '/images/_x_salaire-dun-informaticien.webp',
            description: 'Formation approfondie en programmation, bases de données, réseaux et systèmes informatiques. Nos diplômés sont préparés pour les défis technologiques modernes.',
            category: 'technique',
            detailedInfo: {
                duration: '3 ans',
                cout: '2500€/an',
                debouches: [
                    'Développeur Full Stack (45-70k€/an)',
                    'Architecte Cloud (55-85k€/an)',
                    'Expert en cybersécurité (50-80k€/an)',
                    'DevOps Engineer (48-75k€/an)',
                    'Data Engineer (45-75k€/an)'
                ],
                programme: [
                    'Développement Web & Mobile',
                    'Intelligence Artificielle & Machine Learning',
                    'Cloud Computing & DevOps',
                    'Cybersécurité & Réseaux',
                    'Architecture logicielle'
                ],
                conditions: 'Bac scientifique ou technique avec mention'
            }
        },
        {
            title: 'Genie civil',
            image: '/images/genis.jpg',
            description: 'Formation en conception et réalisation d\'infrastructures. De la construction de bâtiments aux ouvrages d\'art, nos étudiants acquièrent une expertise complète.',
            category: 'technique',
            detailedInfo: {
                duration: '3 ans',
                cout: '2800€/an',
                debouches: [
                    'Ingénieur structure (42-65k€/an)',
                    'Chef de projet BTP (45-70k€/an)',
                    'Expert en géotechnique (40-60k€/an)',
                    'Conducteur de travaux (38-55k€/an)',
                    'Consultant en construction durable (45-65k€/an)'
                ],
                programme: [
                    'Mécanique des structures',
                    'Matériaux innovants',
                    'BIM & modélisation 3D',
                    'Géotechnique avancée',
                    'Management de projets construction'
                ],
                conditions: 'Bac S ou STI2D avec solides bases en mathématiques'
            }
        },
        {
            title: 'Data Science',
            image: '/images/data_science_1.jpg',
            description: 'Formation en analyse de données, intelligence artificielle et machine learning. Préparez-vous à exploiter le potentiel des données massives.',
            category: 'technique',
            detailedInfo: {
                duration: '3 ans',
                cout: '3000€/an',
                debouches: [
                    'Data Scientist (50-85k€/an)',
                    'ML Engineer (55-90k€/an)',
                    'BI Analyst (45-70k€/an)',
                    'Data Engineer (48-75k€/an)',
                    'Research Scientist (60-95k€/an)'
                ],
                programme: [
                    'Machine Learning & Deep Learning',
                    'Statistiques avancées',
                    'Big Data Analytics',
                    'Python & R Programming',
                    'Data Visualization'
                ],
                conditions: 'Bac S spécialité mathématiques ou équivalent'
            }
        },
        {
            title: 'Comptabilité et Finance',
            image: '/images/comptabilite 2.webp',
            description: 'Maîtrisez les principes comptables, la gestion financière et l\'audit. Formation complète pour futurs experts-comptables et analystes financiers.',
            category: 'gestion',
            detailedInfo: {
                duration: '3 ans',
                cout: '2300€/an',
                debouches: [
                    'Expert-comptable (45-80k€/an)',
                    'Contrôleur de gestion (40-65k€/an)',
                    'Auditeur financier (42-70k€/an)',
                    'Analyste financier (45-75k€/an)',
                    'Trésorier d\'entreprise (40-60k€/an)'
                ],
                programme: [
                    'Comptabilité approfondie',
                    'Analyse financière',
                    'Droit fiscal',
                    'Audit & Contrôle',
                    'Finance d\'entreprise'
                ],
                conditions: 'Bac STMG ou général avec option mathématiques'
            }
        },
        {
            title: 'Ressources Humaines',
            image: '/images/rh1.webp',
            description: 'Développez vos compétences en gestion du personnel, recrutement et administration RH. Formation axée sur l\'humain et le management.',
            category: 'gestion',
            detailedInfo: {
                duration: '3 ans',
                cout: '2200€/an',
                debouches: [
                    'DRH (50-90k€/an)',
                    'Chargé de recrutement (35-55k€/an)',
                    'Responsable formation (40-60k€/an)',
                    'Consultant RH (38-65k€/an)',
                    'Responsable SIRH (45-70k€/an)'
                ],
                programme: [
                    'Gestion des talents',
                    'Droit du travail',
                    'SIRH & Digital RH',
                    'Management d\'équipe',
                    'Relations sociales'
                ],
                conditions: 'Bac général ou STMG avec bon niveau en langues'
            }
        },
        {
            title: 'Marketing Digital',
            image: '/images/marketing_digital999.jpeg',
            description: 'Explorez les stratégies marketing modernes, le e-commerce et la communication digitale. Devenez expert en marketing numérique.',
            category: 'gestion',
            detailedInfo: {
                duration: '3 ans',
                cout: '2600€/an',
                debouches: [
                    'Digital Marketing Manager (40-65k€/an)',
                    'Social Media Manager (35-55k€/an)',
                    'Growth Hacker (40-70k€/an)',
                    'SEO Manager (38-60k€/an)',
                    'Content Strategist (35-55k€/an)'
                ],
                programme: [
                    'SEO/SEA & Analytics',
                    'Social Media Strategy',
                    'Content Marketing',
                    'E-commerce & CRM',
                    'Growth Marketing'
                ],
                conditions: 'Bac général ou STMG avec créativité et anglais'
            }
        },
        {
            title: 'Architecture',
            image: '/images/Architecture-1.jpg',
            description: 'Conception architecturale, design urbain et développement durable. Formez-vous à créer les espaces de demain.',
            category: 'technique',
            detailedInfo: {
                duration: '5 ans',
                cout: '3500€/an',
                debouches: [
                    'Architecte DPLG (40-80k€/an)',
                    'Architecte d\'intérieur (35-60k€/an)',
                    'Urbaniste (40-65k€/an)',
                    'BIM Manager (45-70k€/an)',
                    'Chef de projet architectural (50-75k€/an)'
                ],
                programme: [
                    'Design architectural',
                    'Urbanisme durable',
                    'Technologies BIM',
                    'Histoire de l\'architecture',
                    'Éco-construction'
                ],
                conditions: 'Bac S ou STD2A avec portfolio créatif'
            }
        },
        {
            title: 'Mechatronique',
            image: '/images/slidermecatronique2.jpg',
            description: 'Alliance de la mécanique, l\'électronique et l\'informatique. Formation polyvalente pour l\'industrie du futur.',
            category: 'technique',
            detailedInfo: {
                duration: '3 ans',
                cout: '2900€/an',
                debouches: [
                    'Ingénieur mécatronicien (45-70k€/an)',
                    'Roboticien (42-68k€/an)',
                    'Automaticien (40-65k€/an)',
                    'Ingénieur R&D (45-75k€/an)',
                    'Chef de projet industriel (48-72k€/an)'
                ],
                programme: [
                    'Robotique industrielle',
                    'Systèmes embarqués',
                    'IoT & Industry 4.0',
                    'Automatisme avancé',
                    'CAO/CFAO'
                ],
                conditions: 'Bac S ou STI2D avec forte appétence technique'
            }
        }
    ];

    return (
        <>
            <HeroSection1 title={"Nos Filières"} description={"Découvrez nos formations d'excellence pour préparer votre avenir"}></HeroSection1>
            {/* Stats Section */}
            <section className="py-16 bg-gray-100">
                <div className="container mx-auto px-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                        <div className="text-center">
                            <h3 className="text-4xl font-bold text-blue-800 mb-2">12+</h3>
                            <p className="text-gray-600">Filières</p>
                        </div>
                        <div className="text-center">
                            <h3 className="text-4xl font-bold text-blue-800 mb-2">95%</h3>
                            <p className="text-gray-600">Taux d'insertion</p>
                        </div>
                        <div className="text-center">
                            <h3 className="text-4xl font-bold text-blue-800 mb-2">50+</h3>
                            <p className="text-gray-600">Enseignants</p>
                        </div>
                        <div className="text-center">
                            <h3 className="text-4xl font-bold text-blue-800 mb-2">1000+</h3>
                            <p className="text-gray-600">Étudiants</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* Filter Section */}
            <div className="container mx-auto px-4 py-12">
                <div className="flex flex-wrap justify-center gap-4">
                    <button 
                        onClick={() => setFilter('all')}
                        className={`px-6 py-2 rounded-full transition-colors duration-300 cursor-pointer ${filter === 'all' ? 'bg-blue-800 text-white' : 'bg-gray-200'}`}
                    >
                        Toutes les Filieres
                    </button>
                    <button  
                        onClick={() => setFilter('technique')}
                        className={`px-6 py-2 rounded-full transition-colors duration-300 cursor-pointer ${filter === 'technique' ? 'bg-blue-800 text-white' : 'bg-gray-200'}`}
                    >
                        Sciences & Technique
                    </button>
                    <button 
                        onClick={() => setFilter('gestion')}
                        className={`px-6 py-2 rounded-full transition-colors duration-300 cursor-pointer ${filter === 'gestion' ? 'bg-blue-800 text-white' : 'bg-gray-200'}`}
                    >
                        Gestion & Commerce
                    </button>
                </div>
            </div>

            {/* Filières Section */}
            <section className="py-10">
                {filieres
                    .filter(item => filter === 'all' || item.category === filter)
                    .map((item, index) => (
                        <div 
                            key={index}
                            id={item.title.toLowerCase().replace(/\s+/g, '-')}
                            className="scroll-mt-20" // Ajoute une marge pour le scroll
                        >
                            <VisiteComponent 
                                image={item.image} 
                                title={item.title} 
                                description={item.description}
                                detailedInfo={item.detailedInfo} 
                                // Changez props={item.detailedInfo} par detailedInfo={item.detailedInfo}
                            />
                        </div>
                    ))}
            </section>

            {/* FAQ Section */}
            <section className="py-16 bg-gray-100">
                <div className="container mx-auto px-4">
                    <h2 className="text-3xl font-bold text-center mb-12">Questions Fréquentes</h2>
                    <div className="max-w-3xl mx-auto space-y-6">
                        <div className="bg-white p-6 rounded-lg shadow-md">
                            <h3 className="text-xl font-semibold mb-2">Comment s'inscrire ?</h3>
                            <p className="text-gray-600">Pour s'inscrire, vous devez d'abord remplir le formulaire de préinscription en ligne, puis prendre rendez-vous pour finaliser votre inscription sur place avec les documents requis.</p>
                        </div>
                        <div className="bg-white p-6 rounded-lg shadow-md">
                            <h3 className="text-xl font-semibold mb-2">Quels sont les prérequis ?</h3>
                            <p className="text-gray-600">Les prérequis varient selon les filières. Généralement, un baccalauréat ou équivalent est requis. Certaines filières peuvent nécessiter des connaissances spécifiques.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* Scroll to Top Button */}
            <button 
                className={`fixed bottom-8 right-8 bg-blue-800 text-white p-4 rounded-full shadow-lg cursor-pointer transition-opacity duration-300 hover:bg-blue-700 ${showScroll ? 'opacity-100' : 'opacity-0'}`}
                onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}
            >
                <BiSolidArrowFromBottom size={30}/>
            </button>
        </>
    );
}

export default FilierePage;