import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { lazy, Suspense, useEffect } from "react";
import Layout from "./Components/Layout";
import Loader from "./Components/Loader";
import { useLocation } from "react-router-dom";

// Composant pour gérer le scroll
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

// Chargement différé des pages
const HomePage = lazy(() => import("./Pages/HomePage"));
const FilierePage = lazy(() => import("./Pages/FilierePage"));
const ContactPage = lazy(() => import("./Pages/ContactPage"));
const AboutPage = lazy(() => import("./Pages/AboutPage"));

const router = createBrowserRouter([
  {
    path: "/",
    element: (
      <Suspense fallback={<Loader />}>
        <Layout>
          <ScrollToTop />
        </Layout>
      </Suspense>
    ),
    children: [
      {
        path: "/",
        element: <HomePage />,
      },
      {
        path: "/filieres",
        element: <FilierePage />,
      },
      {
        path: "/contact",
        element: <ContactPage />,
      },
      {
        path: "/about",
        element: <AboutPage />,
      },
    ],
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;