

// App.jsx
export function Laval() {
    return (
      <div className="min-h-screen flex flex-col">
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-6">
            <h1 className="text-3xl font-bold text-blue-800">Université Laval</h1>
            <nav className="mt-4 flex gap-6 text-gray-600">
              <a href="#" className="hover:text-blue-800">Philanthropie</a>
              <a href="#" className="hover:text-blue-800">Notre université</a>
              <a href="#" className="hover:text-blue-800">International</a>
            </nav>
          </div>
        </header>
  
        {/* Étapes d'admission */}
        <div className="bg-gray-50 py-12">
          <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-4 gap-8">
            {[
              { number: '1', title: 'Trouvez votre programme' },
              { number: '2', title: 'Préparez votre dossier' },
              { number: '3', title: 'Déposez votre demande' },
              { number: '4', title: 'Faites le suivi' },
            ].map((step) => (
              <div key={step.number} className="text-center p-6 bg-white rounded-lg shadow">
                <div className="text-4xl font-bold text-blue-800 mb-4">{step.number}</div>
                <p className="text-gray-700">{step.title}</p>
              </div>
            ))}
          </div>
        </div>
  
        {/* Contenu principal */}
        <main className="flex-grow">
          <div className="max-w-7xl mx-auto px-4 py-12">
            <div className="grid md:grid-cols-3 gap-12">
              
              {/* Section Actualités */}
              <div className="md:col-span-2">
                <h2 className="text-2xl font-bold mb-8">ULaval nouvelles</h2>
                {[
                  {
                    date: '10 mars 2025',
                    title: 'Festival du film étudiant de Québec',
                    content: '23e édition avec une soixantaine de courts métrages...'
                  },
                  {
                    date: '6 mars 2025',
                    title: 'Médicament contre le cancer',
                    content: 'Gaspillage de millions de dollars dans les traitements...'
                  }
                ].map((item, index) => (
                  <article key={index} className="mb-8 pb-8 border-b">
                    <time className="text-gray-500 text-sm">{item.date}</time>
                    <h3 className="text-xl font-semibold mt-2 mb-4">{item.title}</h3>
                    <p className="text-gray-600">{item.content}</p>
                  </article>
                ))}
              </div>
  
              {/* Liens rapides */}
              <div className="md:col-span-1">
                <h2 className="text-2xl font-bold mb-8">Services étudiants</h2>
                {[
                  { 
                    title: 'ÉTUDES SUPÉRIEURES', 
                    content: 'Découvrez tout sur le cheminement aux 2e et 3e cycles' 
                  },
                  { 
                    title: 'VIE ÉTUDIANTE', 
                    content: 'Soutien financier pour activités parascolaires' 
                  }
                ].map((link, index) => (
                  <div key={index} className="p-6 bg-white rounded-lg shadow mb-6 hover:shadow-md transition-shadow">
                    <h3 className="font-semibold text-lg mb-2">{link.title}</h3>
                    <p className="text-gray-600">{link.content}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
  
        {/* Footer */}
        <footer className="border-t mt-12">
          <div className="max-w-7xl mx-auto px-4 py-8 text-center text-gray-600">
            <p>2325, rue de l'Université, Québec (Québec) G1V 0A6</p>
            <p>Téléphone: 418 656-2131 | Sans frais: 1 877 785-2825</p>
            <div className="mt-4 flex justify-center space-x-4">
              <a href="#">Confidentialité</a>
              <a href="#">Conditions d'utilisation</a>
              <a href="#">Accessibilité</a>
            </div>
            <p className="mt-4">© 2025 Université Laval - Tous droits réservés</p>
          </div>
        </footer>
      </div>
    );
  }
  