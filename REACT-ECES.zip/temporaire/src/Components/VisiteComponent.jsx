import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Modal from "./Modal";

gsap.registerPlugin(ScrollTrigger);

const VisiteComponent = (props) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const componentRef = useRef(null);
  const containerleft = useRef(null);
  const containerright = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(containerright.current,
        {
          opacity: 0,
          x: '-100%'
        },
        {
          opacity: 1,
          x: 0,
          duration: 1,
          ease: "power2.out",
          scrollTrigger: {
            trigger: componentRef.current,
            start: "top 85%",
            end: "bottom 10%",
            toggleActions: "play reverse play reverse",
          }
        }
      );

      gsap.fromTo(containerleft.current,
        {
          opacity: 0,
          x: '100%'
        },
        {
          opacity: 1,
          x: 0,
          duration: 1,
          ease: "power2.out",
          scrollTrigger: {
            trigger: componentRef.current,
            start: "top 85%",
            end: "bottom 10%",
            toggleActions: "play reverse play reverse",
          }
        }
      );
    }, componentRef);
  
    return () => ctx.revert();
  }, []);

  return (
    <>
      <div ref={componentRef} className="mx-auto p-4 md:p-16 mt-0 overflow-x-hidden">
        <hr className="mb-6" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-y-8 md:gap-x-16">
          <div ref={containerright} className="relative flex items-center justify-center">
            <div className="relative w-full">
              <div className="absolute top-1/2 -translate-y-1/2 left-[-10px] md:left-[-20px] w-[25px] md:w-[40px] h-[70%] bg-blue-900"></div>
              <div className="absolute top-1/2 -translate-y-1/2 right-[-10px] md:right-[-20px] w-[25px] md:w-[40px] h-[70%] bg-blue-900"></div>
              <img src={props.image} alt={props.title} className="w-full h-70" />
            </div>
          </div>
          
          <div ref={containerleft} className="m-auto px-4 md:px-0 flex flex-col gap-y-4">
            <h3 className="text-[25px] md:text-[35px] font-light font-['Roboto',sans-serif]">
              {props.title}
            </h3>
            <p className="text-base md:text-lg leading-relaxed">
              {props.description}
            </p>
            <button
              onClick={() => setIsModalOpen(true)}
              type="button"
              className="w-[150px] h-[50px] bg-[#3822b6e3] text-white text-[15px] font-bold border border-transparent hover:bg-[#4426f0f5] hover:cursor-pointer transition-colors duration-300"
            >
              Découvrir
            </button>
          </div>
        </div>
      </div>

      <Modal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        data={props}
      />
    </>
  );
};

export default VisiteComponent;