import React from 'react';
import { FaFacebook, FaTwitter, FaTiktok, FaInstagram, FaEnvelope, FaPhone } from 'react-icons/fa';
import { Logo } from './Headers';

export function Footer() {
    return (
        <footer className="bg-gray-800 text-white py-8 ">
            <div className="container mx-auto px-4">
                <div className="flex flex-col md:flex-row justify-between items-center">
                    <div className="mb-4 md:mb-0">
                        <Logo />
                        <p className="mt-2 text-sm">Grâce à ses enseignants dévoués, ses installations modernes et son <br/> environnement d'apprentissage inclusif, l'École Communautaire de <br/>l'Enseignement Supérieur est un lieu où les étudiants peuvent s'épanouir et <br/> réaliser leur plein potentiel..</p>
                    </div>
                    <div className="flex space-x-4">
                        <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-blue-500 transition-transform duration-300 hover:-translate-y-2">
                            <FaFacebook size={30} />
                        </a>
                        <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-blue-500 transition-transform duration-300 hover:-translate-y-2">
                            <FaTwitter size={30} />
                        </a>
                        <a href="https://www.tiktok.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-blue-500 transition-transform duration-300 hover:-translate-y-2">
                            <FaTiktok size={30} />
                        </a>
                        <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-blue-500 transition-transform duration-300 hover:-translate-y-2">
                            <FaInstagram size={30} />
                        </a>
                    </div>
                </div>
                <div className="mt-4 flex justify-center space-x-4">
                    <div className="flex items-center space-x-2">
                        <FaEnvelope size={25} />
                        <span>contact@eces.com</span>
                    </div>
                    <div className="flex items-center space-x-2">
                        <FaPhone size={25} />
                        <span>+242067052578</span>
                    </div>
                </div>
                <div className="mt-4 text-center text-sm flex flex-col">
                    &copy; 2025 ECES.Crée par Loulengo Jacques Euthyche.
                    &copy; Email:loulengogaara@gmail.com.

                </div>
            </div>
        </footer>
    );
}