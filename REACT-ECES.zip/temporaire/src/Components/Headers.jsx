import { useState } from "react";
import { NavLink } from "react-router-dom";

const navigationLinks = [
  { text: 'Accueil', path: '/' },
  { text: 'Filières', path: '/filieres' },
  { text: 'À propos', path: '/about' },
  { text: 'Contact', path: '/contact' }
];

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleMenuClick = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="fixed w-full shadow-md z-50 py-2 transition-all duration-300 hover:shadow-lg bg-zinc-100">
      <div className="container mx-auto px-6 flex justify-between items-center">
        <Logo />
        <div className="hidden sm:flex gap-8 bg-gray-800 py-2 px-6 rounded">
          {navigationLinks.map((item) => (
            <NavLink 
              key={item.text} 
              to={item.path} 
              className="text-white font-bold hover:scale-115 cursor-pointer transition-all duration-300"
            >
              {item.text}
            </NavLink>
          ))}
        </div>
        <div className='sm:hidden'>
          <BurgerMenu isMenuOpen={isMenuOpen} onClick={handleMenuClick} />
        </div>
      </div>
      <div className={`sm:hidden ${isMenuOpen ? 'max-h-98' : 'max-h-0'} overflow-hidden bg-zinc-50 transition-all duration-300`}>
        <div className="container mx-auto px-6 py-4 flex flex-col gap-4">
          {navigationLinks.map((item) => (
            <NavLink 
              key={item.text} 
              to={item.path} 
              onClick={handleMenuClick}
              className="text-gray-600 hover:text-blue-800 cursor-pointer transition-all duration-300"
            >
              {item.text}
            </NavLink>
          ))}
        </div>
      </div>
    </nav>
  );
}

export function Logo() {
  return (
    <div className="font1 flex text-4xl items-center gap-2 font-bold text-blue-800">
      <img className="h-[60px]" src="/images/Logo ECES.png" alt="Logo Eces" />
      ECES
    </div>
  );
}

export function BurgerMenu({ isMenuOpen, onClick }) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col justify-center items-center space-y-1 mt-1 focus:outline-none sm:hidden"
    >
      <div className={`w-8 h-1 bg-black transition-transform duration-300 ${
        isMenuOpen ? 'rotate-45 translate-y-2' : ''
      }`}></div>
      <div className={`w-8 h-1 bg-black transition-opacity duration-300 ${
        isMenuOpen ? 'opacity-0' : 'opacity-100'
      }`}></div>
      <div className={`w-8 h-1 bg-black transition-transform duration-300 ${
        isMenuOpen ? '-rotate-45 -translate-y-2' : ''
      }`}></div>
    </button>
  );
}