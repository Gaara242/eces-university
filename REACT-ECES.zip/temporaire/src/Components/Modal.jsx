import { useEffect, useRef } from 'react';
import { ModalAnimation } from '../assets/animations/heroAnimations';
import { CgClose } from 'react-icons/cg';

const Modal = ({ isOpen, onClose, data }) => {
    const modalRef = useRef(null);

    useEffect(() => {
        if (isOpen && modalRef.current) {
            ModalAnimation.fadeIn(modalRef.current);
        }
    }, [isOpen]);

    const handleClose = () => {
        ModalAnimation.fadeOut(modalRef.current, onClose);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div ref={modalRef} className="bg-white rounded-lg max-w-4xl w-full relative">
            <button 
                    onClick={handleClose}
                    className="absolute top-4 right-4 cursor-pointer text-gray-900 hover:text-red-500"
              >
                <CgClose size={35} />
            </button>
        
        <div className="p-8">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/2">
              <img 
                src={data.image} 
                alt={data.title} 
                className="w-full h-[100%] rounded-lg shadow-lg object-cover"
              />
            </div>
            <div className="md:w-1/2 space-y-6">
                <h3 className="text-2xl font-bold text-gray-800">{data.title}</h3>

                <div>
                    <h4 className="text-lg font-semibold text-blue-800">Débouchés</h4>
                    <ul className="list-disc list-inside text-gray-600 space-y-1">
                        {data.detailedInfo?.debouches.map((debouche, index) => (
                            <li key={index}>{debouche}</li>
                        ))}
                    </ul>
                </div>

              <div>
                <h4 className="text-lg font-semibold text-blue-800">Programme</h4>
                    <ul className="list-disc list-inside text-gray-600 space-y-1">
                    {data.detailedInfo?.programme.map((item, index) => (
                        <li key={index}>{item}</li>
                    ))}
                </ul>
              </div>

              <div className="flex gap-x-8">
                <div>
                  <h4 className="text-lg font-semibold text-blue-800">Durée</h4>
                  <p className="text-gray-600">{data.detailedInfo?.duration}</p>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-blue-800">Coût</h4>
                  <p className="text-gray-600">{data.detailedInfo?.cout}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;