export function Cours ({course}){
    return <>
        <div key={course.title} className="bg-white p-6 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:-translate-y-4 cours-animation">
            <div className="text-blue-800 mb-4">{course.icon}</div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">{course.title}</h3>
            <p className="text-gray-600 mb-4">Texte descriptif du cours...</p>
            <a 
                href={`/filieres`}
                className="text-blue-800 font-semibold flex items-center gap-2 hover:gap-4 cursor-pointer transition-all"
            >
                DÉTAILS DU COURS <span className="text-lg">→</span>
            </a>
        </div>
    </>;
}