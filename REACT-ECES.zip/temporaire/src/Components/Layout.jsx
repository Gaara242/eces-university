import { Header } from "./Headers";
import { Footer } from "./Footer";
import { Outlet, useLocation } from "react-router-dom";
import { Suspense, useState, useEffect } from "react";
import Loader from "./Loader";
import { BiSolidArrowFromBottom } from 'react-icons/bi';
export default function Layout() {
  const { pathname } = useLocation();
  const [showScroll, setShowScroll] = useState(false);

  useEffect(() => {
    const scrollToTop = () => {
      window.scrollTo({
        top: 0,
        behavior: "instant" // Changement de "smooth" à "instant" pour un défilement immédiat
      });
    };
    scrollToTop();
  }, [pathname]);


  useEffect(() => {
    const checkScrollTop = () => {
      if (!showScroll && window.pageYOffset > 400) {
        setShowScroll(true);
      } else if (showScroll && window.pageYOffset <= 400) {
        setShowScroll(false);
      }
    };
    window.addEventListener('scroll', checkScrollTop);
    return () => window.removeEventListener('scroll', checkScrollTop);
  }, [showScroll]);



  return (
    <div className="min-h-screen font-sans scroll-smooth">
      <Header />
      <br /><br /><br />
      <Suspense fallback={<Loader />}>
        <Outlet />
      </Suspense>
      <Footer />
      
      <button 
        className={`fixed bottom-8 right-8 bg-blue-800 text-white p-4 rounded-full shadow-lg cursor-pointer transition-opacity duration-300 hover:bg-blue-700 z-50 ${showScroll ? 'opacity-100' : 'opacity-0'}`}
        onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}
      >
        <BiSolidArrowFromBottom size={30}/>
      </button>
    </div>
  );
}