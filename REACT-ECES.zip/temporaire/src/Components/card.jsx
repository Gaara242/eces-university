

export function HorizontalCard({props}){

    return (
        <>
        <div className="bg-white p-6 rounded-lg shadow-md transition-transform duration-300 hover:scale-105">
            <p className="text-blue-700 italic mb-4">{props.competence}</p>
            <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-full"><img className="rounded-s-full" src={props.image} alt={props.name} /></div>
                <div>
                    <h4 className="font-bold text-amber-800">{props.name}</h4>
                    <p className="text-blue-900">Regular Customer</p>
                </div>
            </div>
        </div>
        </>
    )
}