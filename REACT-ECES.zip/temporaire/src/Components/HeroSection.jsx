import { useEffect, useRef } from 'react';
import { createHeroAnimation, createHeroAnimation1, SlidIn } from '../assets/animations/heroAnimations';
import { Link } from 'react-router-dom';

export function HeroSection() {
  const bgRef = useRef(null);
  const contentRef = useRef(null);
  const videoRef = useRef(null);
  const titleRef = useRef(null);
  const subtitleRef = useRef(null);
  useEffect(() => {
    const ctx = createHeroAnimation1(contentRef);
    return () => ctx.revert();
  }, []);

  return (
    <>
      <section className="relative h-[500px] flex items-center justify-center pt-20 overflow-hidden">
        <div ref={bgRef} className="absolute inset-0">
          <div className="absolute inset-0">
            <img 
              src="/images/2019 (18) (1).jpg" 
              alt="ECES Background" 
              className="w-full h-full object-cover"
            />
          </div>

          <div className="absolute inset-0">
            <video 
              ref={videoRef}
              autoPlay 
              loop 
              muted 
              playsInline
              className="w-full h-full object-cover opacity-60"
            >
              <source src="/videos/snow-fall.webm" type="video/mp4" />
            </video>
          </div>
        </div>

        {/* Overlay sombre avec opacité réduite */}
        <div className="absolute inset-0 bg-white-black/1 z-10" /> 

        {/* Contenu */}
        <div ref={contentRef}className="flex flex-col items-center relative z-20 px-2 text-white space-y-4 mb-20">
          <h1 
            ref={titleRef}
            className="font-['DynaPuff'] text-7xl md:text-10xl font-bold drop-shadow-md"
          >
            ECES
          </h1>
          <p ref={subtitleRef}className="font2 text-md text-center md:text-2xl max-w-3xl mx-auto leading-relaxed mb-4" >
              ECOLE COMMUNAUTAIRE DE L'ENSEGEMENT SUPERIEUR
          </p>
          <div className="flex gap-4 justify-center mt-2">
            <button className="bg-blue-800 px-8 py-3 text-l rounded-lg text-lg hover:bg-blue-900 transition-all duration-300 hover:scale-105">
              <Link to={'/filieres'}>VOIR PROGRAMMES</Link>
            </button>
            <button className="border-2 border-white px-8 py-3 rounded-lg text-lg hover:bg-white/10 transition-all duration-300 hover:scale-105">
              <Link to={'/about'}>EN SAVOIR PLUS</Link>
            </button>
          </div>
        </div>        
    </section>
  </>
    );
}


export function HeroSection1({title, description}){
  const titleRef = useRef(null);
  const subtitleRef = useRef(null);
  const contentRef = useRef(null);

  useEffect(() => {
    const ctx = createHeroAnimation1(contentRef);
    return () => ctx.revert();
  }, []);

  return(
    <section ref={contentRef} className="relative h-[50vh] bg-gradient-to-r from-blue-900 to-blue-700">
      <div className="absolute inset-0 bg-black opacity-50"></div>
      <div className="relative z-10 h-full flex flex-col justify-center items-center text-white px-4">
        <h1 ref={titleRef} className="text-4xl md:text-6xl font-bold text-center mb-4">
          {title}
        </h1>
        <p ref={subtitleRef} className="text-xl md:text-2xl text-center max-w-3xl">
          {description}
        </p>
      </div>
    </section>
  )
}