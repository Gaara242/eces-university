import React from 'react';

const Loader = () => {
    return (
        <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center bg-white bg-opacity-90 z-50">
            <video
                className="w-70 h-70"
                autoPlay
                loop
                muted
            >
                <source src="/videos/Animation - 1742426103651.webm" type="video/mp4" />
                Votre navigateur ne supporte pas la lecture de vidéos.
            </video>
        </div>
    );
};

export default Loader;