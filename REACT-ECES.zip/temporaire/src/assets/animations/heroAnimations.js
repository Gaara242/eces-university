import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { TextPlugin } from "gsap/TextPlugin";

gsap.registerPlugin(ScrollTrigger, TextPlugin);

export const createHeroAnimation = (bgRef, contentRef) => {
  const ctx = gsap.context(() => {

    gsap.fromTo(bgRef.current,
      {
        opacity: 0,
        scale: 1.1
      },
      {
        opacity: 1,
        scale: 1,
        duration: 1.5,
        ease: "power2.out"
      }
    );

    gsap.fromTo(contentRef.current.querySelector('h1'),
      {
        text: "",
        opacity: 1
      },
      {
        duration: 1,
        text: "ECES",
        ease: "none",
        delay: 0.5
      }
    );

    const subtitle = contentRef.current.querySelector('p');
    gsap.fromTo(subtitle,
      {
        text: "",
        opacity: 1
      },
      {
        duration: 3,
        text: "ECOLE COMMUNAUTAIRE DE L'ENSEGEMENT SUPERIEUR",
        ease: "none",
        delay: 2.5,
      }
    );
  });

  return ctx;
};

export const SlidIn = (containerRef) => {
    const ctx = gsap.context(() => {
        const elements = gsap.utils.toArray('.animate-slide');
        
        elements.forEach((element, index) => {
            gsap.fromTo(
                element,
                {
                    y: '50px',
                    opacity: 0,
                },
                {
                    y: '0px',
                    duration: 1,
                    opacity: 1,
                    ease: "power2.out",
                    scrollTrigger: {
                        trigger: element,
                        start: 'top 80%',
                        end:'bottom 20%',
                        toggleActions: 'play reverse play reverse',
                    },
                    delay: index * 0.2
                }
            );
        });
    }, containerRef);

    return ctx;
};

export const FadeInScale = (containerRef) => {
  const ctx = gsap.context(() => {
      gsap.fromTo(
          containerRef.current,
          {
              opacity: 0,
              scale: 0.9
          },
          {
              opacity: 1,
              scale: 1,
              duration: 0.5,
              ease: "power2.out"
          }
      );
  }, containerRef);

  return ctx;
};

export const ModalAnimation = {
  fadeIn: (element) => {
      gsap.fromTo(
          element,
          {
              opacity: 0,
              y: 20,
              scale: 0.95
          },
          {
              opacity: 1,
              y: 0,
              scale: 1,
              duration: 0.3,
              ease: "power2.out"
          }
      );
  },
  
  fadeOut: (element, onComplete) => {
      gsap.to(
          element,
          {
              opacity: 0,
              y: -20,
              scale: 0.95,
              duration: 0.2,
              ease: "power2.in",
              onComplete: onComplete
          }
      );
  }
};

export const createHeroAnimation1 = (contentRef) => {
  const ctx = gsap.context(() => {
    // Animation du fond
    gsap.fromTo(contentRef.current,
      {
        opacity: 0,
        scale: 1.1
      },
      {
        opacity: 1,
        scale: 1,
        duration: 1.5,
        ease: "power2.out"
      }
    );

    // Animation du titre avec effet machine à écrire
    const title = contentRef.current.querySelector('h1');
    gsap.fromTo(title,
      {
        text: "",
        opacity: 1
      },
      {
        duration: 1,
        text: title.textContent,
        ease: "none",
        delay: 0.5
      }
    );

    // Animation de la description avec effet machine à écrire
    const description = contentRef.current.querySelector('p');
    gsap.fromTo(description,
      {
        text: "",
        opacity: 1
      },
      {
        duration: 3,
        text: description.textContent,
        ease: "none",
        delay: 1.5
      }
    );
  });

  return ctx;
};
